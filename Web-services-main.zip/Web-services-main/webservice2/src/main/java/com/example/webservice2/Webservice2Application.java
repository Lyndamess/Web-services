package com.example.webservice2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Webservice2Application {

	public static void main(String[] args) {
		SpringApplication.run(Webservice2Application.class, args);
	}

}
